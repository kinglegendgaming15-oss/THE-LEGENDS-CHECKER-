using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace TheLegendsChecker
{
    public class PlayerScanner : MonoBehaviour
    {
        private bool panelVisible;

        public void TogglePanel()
        {
            panelVisible = !panelVisible;

            if (panelVisible)
                Plugin.Instance.Menu.ShowScan(
                    "PLAYER SCANNER\n" +
                    "Point your right hand at a player.\n\n" +
                    "CHEAT STATUS: UNKNOWN");
        }
    }

    // The scanner intentionally does not read another player's
    // computer, files, processes, or installed programs.
    // It only uses information legitimately exposed to the game client.
}
