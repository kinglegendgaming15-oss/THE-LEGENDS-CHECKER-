using BepInEx;
using UnityEngine;

namespace TheLegendsChecker
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class Plugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.kinglegend.thelegendschecker";
        public const string PluginName = "THE LEGEND'S CHECKER";
        public const string PluginVersion = "1.0.0";

        internal static Plugin Instance;
        internal ThemeManager Themes;
        internal VRMenu Menu;
        internal NameTagManager NameTags;
        internal PlayerScanner Scanner;
        internal LobbyManager Lobby;
        internal ModVerification Verification;

        private void Awake()
        {
            Instance = this;

            Themes = gameObject.AddComponent<ThemeManager>();
            Verification = gameObject.AddComponent<ModVerification>();
            Lobby = gameObject.AddComponent<LobbyManager>();
            NameTags = gameObject.AddComponent<NameTagManager>();
            Scanner = gameObject.AddComponent<PlayerScanner>();
            Menu = gameObject.AddComponent<VRMenu>();

            Logger.LogInfo(PluginName + " loaded.");
        }

        private void OnDestroy()
        {
            if (Instance == this)
                Instance = null;
        }
    }
}
