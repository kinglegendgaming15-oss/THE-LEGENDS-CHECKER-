using UnityEngine;

namespace TheLegendsChecker
{
    public class ThemeManager : MonoBehaviour
    {
        public readonly string[] Names =
        {
            "FOREST GREEN", "RED", "GREEN", "BLUE",
            "MIDNIGHT BLUE", "DARK RED", "BLACK",
            "PURPLE", "DARK PURPLE"
        };

        public readonly Color[] Colors =
        {
            new Color(0.04f, 0.30f, 0.10f),
            new Color(0.65f, 0.02f, 0.02f),
            new Color(0.02f, 0.55f, 0.06f),
            new Color(0.02f, 0.20f, 0.75f),
            new Color(0.01f, 0.04f, 0.18f),
            new Color(0.30f, 0.01f, 0.01f),
            new Color(0.01f, 0.01f, 0.01f),
            new Color(0.45f, 0.04f, 0.75f),
            new Color(0.16f, 0.01f, 0.28f)
        };

        public int Current { get; private set; } = 7;

        public Color CurrentColor
        {
            get { return Colors[Current]; }
        }

        public string CurrentName
        {
            get { return Names[Current]; }
        }

        public void Next()
        {
            Current = (Current + 1) % Names.Length;
        }
    }
}
