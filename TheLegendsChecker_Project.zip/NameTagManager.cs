using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

namespace TheLegendsChecker
{
    public class NameTagManager : MonoBehaviour
    {
        private bool enabledTags = true;
        private readonly Dictionary<int, GameObject> tags =
            new Dictionary<int, GameObject>();

        public void Toggle()
        {
            enabledTags = !enabledTags;

            foreach (GameObject tag in tags.Values)
                if (tag != null) tag.SetActive(enabledTags);
        }

        private void Update()
        {
            if (!PhotonNetwork.InRoom)
                return;

            foreach (Player player in PhotonNetwork.PlayerList)
            {
                if (player == null || player.IsLocal)
                    continue;

                if (!tags.ContainsKey(player.ActorNumber))
                {
                    GameObject avatar = FindAvatar(player);
                    if (avatar != null)
                        tags[player.ActorNumber] =
                            CreateTag(avatar, player);
                }

                if (tags.ContainsKey(player.ActorNumber) &&
                    tags[player.ActorNumber] != null)
                    tags[player.ActorNumber].SetActive(enabledTags);
            }

            List<int> remove = new List<int>();

            foreach (int actor in tags.Keys)
            {
                bool found = false;
                foreach (Player p in PhotonNetwork.PlayerList)
                {
                    if (p != null && p.ActorNumber == actor)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                    remove.Add(actor);
            }

            foreach (int actor in remove)
            {
                if (tags[actor] != null)
                    Destroy(tags[actor]);
                tags.Remove(actor);
            }
        }

        private GameObject FindAvatar(Player player)
        {
            PhotonView[] views = FindObjectsOfType<PhotonView>();

            foreach (PhotonView view in views)
            {
                if (view != null &&
                    view.Owner != null &&
                    view.Owner.ActorNumber == player.ActorNumber)
                    return view.gameObject;
            }

            return null;
        }

        private GameObject CreateTag(GameObject avatar, Player player)
        {
            GameObject tag = new GameObject("Tag_" + player.ActorNumber);
            tag.transform.SetParent(avatar.transform, false);
            tag.transform.localPosition = new Vector3(0, 0.65f, 0);
            tag.transform.localScale = Vector3.one * 0.003f;

            Canvas canvas = tag.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = Camera.main;

            TextMeshProUGUI text =
                tag.AddComponent<TextMeshProUGUI>();

            text.text =
                player.NickName +
                "\nPLATFORM: UNKNOWN";

            text.fontSize = 25;
            text.alignment = TextAlignmentOptions.Center;
            text.color = Color.white;

            RectTransform rect = tag.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(500, 130);

            return tag;
        }

        private void OnDestroy()
        {
            foreach (GameObject tag in tags.Values)
                if (tag != null) Destroy(tag);

            tags.Clear();
        }
    }
}
