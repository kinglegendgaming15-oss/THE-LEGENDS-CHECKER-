# THE LEGEND'S CHECKER

A BepInEx/Unity starter project for a Gorilla Tag PC mod.

## Included

- VR wrist menu
- Right-controller primary-button toggle
- 9 themes
- Player name tags
- Room/player information
- Player scanner UI
- Leave Lobby
- Join Random Lobby
- Opt-in verified-mod status API

## Important limitation

This project intentionally does **not** scan another player's computer, files,
processes, or installed programs. A client-side Gorilla Tag mod cannot legitimately
inspect another player's PC through Photon.

The scanner therefore reports only information exposed to your client and uses
`UNKNOWN` when a cheating/mod status cannot be verified.

## Building

1. Install the .NET SDK compatible with your BepInEx setup.
2. Set `GT_DIR` in the `.csproj` to your Gorilla Tag installation directory.
3. Verify the referenced DLL names exist in your current Gorilla Tag installation.
4. Build the project.
5. Copy `TheLegendsChecker.dll` into:
   `Gorilla Tag/BepInEx/plugins/`

## Version compatibility

Gorilla Tag updates can change Unity, Photon, VR object names, and assemblies.
If your current version uses different assembly names or VR controller objects,
update the references and the `FindRightHand()` method accordingly.

## Platform detection

The starter implementation displays `PLATFORM: UNKNOWN` rather than guessing.
A real platform detector needs a reliable platform value exposed by the exact
Gorilla Tag version being targeted.

## Verification

`ModVerification.cs` is intentionally opt-in. To show verified mods, connect it
to a trusted verification service that receives information voluntarily from a
compatible plugin/server. Do not use it to access another player's private files.
