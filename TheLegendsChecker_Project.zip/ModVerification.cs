using System.Collections.Generic;
using UnityEngine;

namespace TheLegendsChecker
{
    public class ModVerification : MonoBehaviour
    {
        // This is deliberately an empty, opt-in verification layer.
        // It does NOT scan another player's PC.
        //
        // A future trusted server/plugin can populate verified
        // information here after receiving an explicit report.
        private readonly HashSet<string> verifiedMods =
            new HashSet<string>();

        public bool IsVerified(string userId)
        {
            return !string.IsNullOrEmpty(userId) &&
                   verifiedMods.Contains(userId);
        }

        public string GetStatus(string userId)
        {
            return IsVerified(userId)
                ? "VERIFIED"
                : "UNKNOWN";
        }

        public void Clear()
        {
            verifiedMods.Clear();
        }
    }
}
