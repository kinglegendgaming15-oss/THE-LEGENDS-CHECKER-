using Photon.Pun;
using UnityEngine;

namespace TheLegendsChecker
{
    public class LobbyManager : MonoBehaviour
    {
        public void Leave()
        {
            if (PhotonNetwork.InRoom)
                PhotonNetwork.LeaveRoom();
        }

        public void JoinRandom()
        {
            if (PhotonNetwork.InRoom)
            {
                PhotonNetwork.LeaveRoom();
                Invoke(nameof(Join), 0.5f);
            }
            else
            {
                Join();
            }
        }

        private void Join()
        {
            if (!PhotonNetwork.InRoom)
                PhotonNetwork.JoinRandomRoom();
        }
    }
}
