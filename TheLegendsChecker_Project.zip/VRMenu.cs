using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR;

namespace TheLegendsChecker
{
    public class VRMenu : MonoBehaviour
    {
        private GameObject root;
        private Image background;
        private TextMeshProUGUI themeText;
        private TextMeshProUGUI roomText;
        private TextMeshProUGUI scannerText;

        private Transform rightHand;
        private InputDevice rightController;
        private bool lastPrimary;
        private bool open;

        private readonly List<GameObject> buttons = new List<GameObject>();

        public bool IsOpen { get { return open; } }

        private void Start()
        {
            CreateMenu();
            CreateScannerPanel();
            root.SetActive(false);
        }

        private void Update()
        {
            FindRightHand();
            HandleController();

            if (open && rightHand != null)
            {
                root.transform.position =
                    rightHand.position + rightHand.forward * 0.08f;
                root.transform.rotation = rightHand.rotation;
            }

            UpdateRoomText();
            ApplyTheme();
        }

        private void FindRightHand()
        {
            if (rightHand != null) return;

            GameObject go = GameObject.Find("RightHand Controller");
            if (go != null) rightHand = go.transform;
        }

        private void HandleController()
        {
            if (!rightController.isValid)
                rightController = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

            if (!rightController.isValid) return;

            bool pressed = false;
            rightController.TryGetFeatureValue(CommonUsages.primaryButton, out pressed);

            if (pressed && !lastPrimary)
                Toggle();

            lastPrimary = pressed;
        }

        public void Toggle()
        {
            open = !open;
            root.SetActive(open);
            if (!open) scannerText.gameObject.SetActive(false);
        }

        private void CreateMenu()
        {
            root = new GameObject("TheLegendsChecker_Menu");
            Canvas canvas = root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = Camera.main;

            RectTransform cr = canvas.GetComponent<RectTransform>();
            cr.sizeDelta = new Vector2(800, 900);
            root.transform.localScale = Vector3.one * 0.0015f;

            GameObject bg = new GameObject("Background");
            bg.transform.SetParent(root.transform, false);
            background = bg.AddComponent<Image>();
            background.color = Plugin.Instance.Themes.CurrentColor;
            RectTransform br = bg.GetComponent<RectTransform>();
            br.sizeDelta = new Vector2(760, 850);

            MakeText("TITLE", "THE LEGEND'S CHECKER", new Vector2(0, 370), 42);
            roomText = MakeText("ROOM", "NOT IN ROOM", new Vector2(0, 310), 22);

            MakeButton("SCAN", "PLAYER SCANNER", new Vector2(0, 210),
                delegate { Plugin.Instance.Scanner.TogglePanel(); });

            MakeButton("TAGS", "TOGGLE NAME TAGS", new Vector2(0, 125),
                delegate { Plugin.Instance.NameTags.Toggle(); });

            MakeButton("THEME", "CHANGE THEME", new Vector2(0, 40),
                delegate { Plugin.Instance.Themes.Next(); });

            MakeButton("LEAVE", "LEAVE LOBBY", new Vector2(-175, -100),
                delegate { Plugin.Instance.Lobby.Leave(); });

            MakeButton("RANDOM", "JOIN RANDOM LOBBY", new Vector2(175, -100),
                delegate { Plugin.Instance.Lobby.JoinRandom(); });

            themeText = MakeText("THEME_TEXT",
                "THEME: " + Plugin.Instance.Themes.CurrentName,
                new Vector2(0, -200), 22);
        }

        private TextMeshProUGUI MakeText(
            string name, string text, Vector2 position, float size)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(root.transform, false);

            TextMeshProUGUI tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = size;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.color = Color.white;

            RectTransform r = tmp.GetComponent<RectTransform>();
            r.anchoredPosition = position;
            r.sizeDelta = new Vector2(700, 70);

            return tmp;
        }

        private void MakeButton(
            string name, string text, Vector2 position, UnityEngine.Events.UnityAction action)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(root.transform, false);

            Image image = go.AddComponent<Image>();
            image.color = new Color(0.04f, 0.04f, 0.04f, 0.95f);

            Button button = go.AddComponent<Button>();
            button.onClick.AddListener(action);

            RectTransform r = go.GetComponent<RectTransform>();
            r.anchoredPosition = position;
            r.sizeDelta = new Vector2(300, 65);

            GameObject textGo = new GameObject("Text");
            textGo.transform.SetParent(go.transform, false);

            TextMeshProUGUI tmp = textGo.AddComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = 21;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.color = Color.white;

            RectTransform tr = tmp.GetComponent<RectTransform>();
            tr.anchorMin = Vector2.zero;
            tr.anchorMax = Vector2.one;
            tr.offsetMin = Vector2.zero;
            tr.offsetMax = Vector2.zero;

            buttons.Add(go);
        }

        private void CreateScannerPanel()
        {
            scannerText = MakeText(
                "SCANNER_PANEL",
                "PLAYER SCANNER\nPoint at a player\n\nCHEAT STATUS: UNKNOWN",
                new Vector2(0, 0), 24);

            scannerText.gameObject.SetActive(false);
        }

        public void ShowScan(string text)
        {
            scannerText.text = text;
            scannerText.gameObject.SetActive(true);
        }

        private void UpdateRoomText()
        {
            if (roomText == null) return;

            if (Photon.Pun.PhotonNetwork.InRoom)
            {
                roomText.text =
                    "ROOM: " +
                    Photon.Pun.PhotonNetwork.CurrentRoom.Name +
                    " • PLAYERS: " +
                    Photon.Pun.PhotonNetwork.PlayerList.Length;
            }
            else
            {
                roomText.text = "NOT IN ROOM";
            }
        }

        private void ApplyTheme()
        {
            if (background != null)
                background.color = Plugin.Instance.Themes.CurrentColor;

            if (themeText != null)
                themeText.text =
                    "THEME: " + Plugin.Instance.Themes.CurrentName;
        }
    }
}
